import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Search, Calendar, Clock, MapPin, User, Filter } from "lucide-react"

const Agendamentos = () => {
  const [searchTerm, setSearchTerm] = useState("")
  
  const agendamentos = [
    {
      id: 1,
      professor: "Ana Silva",
      materia: "Matemática",
      serie: "9º Ano",
      data: "2024-01-15",
      horaInicial: "14:00",
      horaFinal: "15:00",
      sala: "Sala 101",
      quantidade: 30,
      status: "confirmado",
      observacoes: "Aula sobre equações do 2º grau"
    },
    {
      id: 2,
      professor: "João Santos", 
      materia: "História",
      serie: "8º Ano",
      data: "2024-01-16",
      horaInicial: "15:00",
      horaFinal: "16:00",
      sala: "Sala 201",
      quantidade: 25,
      status: "pendente",
      observacoes: "Revolução Industrial"
    },
    {
      id: 3,
      professor: "Maria Costa",
      materia: "Português", 
      serie: "7º Ano",
      data: "2024-01-17",
      horaInicial: "16:00",
      horaFinal: "17:00",
      sala: "Biblioteca",
      quantidade: 20,
      status: "confirmado",
      observacoes: "Análise de texto literário"
    },
    {
      id: 4,
      professor: "Pedro Lima",
      materia: "Ciências",
      serie: "6º Ano", 
      data: "2024-01-18",
      horaInicial: "13:00",
      horaFinal: "14:00",
      sala: "Laboratório de Ciências",
      quantidade: 28,
      status: "cancelado",
      observacoes: "Experimento com microscópio"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmado':
        return 'bg-success/10 text-success border-success/20'
      case 'pendente':
        return 'bg-warning/10 text-warning border-warning/20'
      case 'cancelado':
        return 'bg-destructive/10 text-destructive border-destructive/20'
      default:
        return 'bg-muted text-muted-foreground'
    }
  }

  const filteredAgendamentos = agendamentos.filter(agendamento =>
    agendamento.professor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agendamento.materia.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agendamento.serie.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agendamento.sala.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Meus Agendamentos</h1>
        <p className="text-muted-foreground">
          Visualize e gerencie seus agendamentos de aula
        </p>
      </div>

      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Lista de Agendamentos
          </CardTitle>
          <CardDescription>
            Todos os seus agendamentos de aula organizados por data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por professor, matéria, série ou sala..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Professor/Matéria</TableHead>
                  <TableHead>Data/Horário</TableHead>
                  <TableHead>Local</TableHead>
                  <TableHead>Alunos</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Observações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAgendamentos.map((agendamento) => (
                  <TableRow key={agendamento.id} className="hover:bg-muted/50">
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{agendamento.professor}</span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {agendamento.materia} - {agendamento.serie}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{formatDate(agendamento.data)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {agendamento.horaInicial} - {agendamento.horaFinal}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{agendamento.sala}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="font-medium">{agendamento.quantidade}</span>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={getStatusColor(agendamento.status)}
                      >
                        {agendamento.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground max-w-[200px] truncate block">
                        {agendamento.observacoes}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredAgendamentos.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nenhum agendamento encontrado</p>
              <p className="text-sm">Tente ajustar os filtros de busca</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default Agendamentos