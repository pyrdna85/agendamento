// Página inicial - redirecionamento é tratado no App.tsx
const Index = () => {
  return null;
};

export default Index;
