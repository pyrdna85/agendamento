import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, Users, BookOpen } from "lucide-react"

const Dashboard = () => {
  const stats = [
    {
      title: "Agendamentos Hoje",
      value: "12",
      description: "3 pendentes de confirmação",
      icon: Calendar,
      color: "text-primary"
    },
    {
      title: "Próximas Aulas",
      value: "8",
      description: "Nas próximas 2 horas",
      icon: Clock,
      color: "text-accent"
    },
    {
      title: "Alunos Ativos",
      value: "245",
      description: "Cadastrados este mês",
      icon: Users,
      color: "text-success"
    },
    {
      title: "Matérias",
      value: "8",
      description: "Disponíveis para agendamento",
      icon: BookOpen,
      color: "text-warning"
    }
  ]

  const recentSchedules = [
    { id: 1, professor: "Ana Silva", materia: "Matemática", serie: "9º Ano", horario: "14:00 - 15:00", status: "confirmado" },
    { id: 2, professor: "João Santos", materia: "História", serie: "8º Ano", horario: "15:00 - 16:00", status: "pendente" },
    { id: 3, professor: "Maria Costa", materia: "Português", serie: "7º Ano", horario: "16:00 - 17:00", status: "confirmado" },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Visão geral dos seus agendamentos e atividades
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="shadow-card hover:shadow-elegant transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2 shadow-card">
          <CardHeader>
            <CardTitle>Agendamentos Recentes</CardTitle>
            <CardDescription>
              Últimos agendamentos realizados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSchedules.map((schedule) => (
                <div
                  key={schedule.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-card/50"
                >
                  <div>
                    <p className="font-medium">{schedule.professor}</p>
                    <p className="text-sm text-muted-foreground">
                      {schedule.materia} - {schedule.serie}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{schedule.horario}</p>
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                        schedule.status === 'confirmado'
                          ? 'bg-success/10 text-success'
                          : 'bg-warning/10 text-warning'
                      }`}
                    >
                      {schedule.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Equipamentos</CardTitle>
            <CardDescription>
              Status dos equipamentos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Projetores</span>
                <span className="text-sm font-medium text-success">8/10 Disponíveis</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Computadores</span>
                <span className="text-sm font-medium text-success">25/30 Disponíveis</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Microscópios</span>
                <span className="text-sm font-medium text-warning">2/5 Disponíveis</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Laboratório</span>
                <span className="text-sm font-medium text-success">3/3 Disponíveis</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Dashboard