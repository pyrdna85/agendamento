import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Calendar, Clock, Users, BookOpen, MapPin, Plus, Trash2 } from "lucide-react"

const NovoAgendamento = () => {
  const { toast } = useToast()
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [formData, setFormData] = useState({
    nomeProfessor: "",
    serie: "",
    materia: "",
    horaInicial: "",
    horaFinal: "",
    quantidade: "",
    data: "",
    sala: "",
    observacoes: ""
  })

  const materias = [
    "Matemática",
    "História", 
    "Português",
    "Inglês",
    "Educação Física",
    "Educação Artística",
    "Maker",
    "Música",
    "Ciências",
    "Geografia"
  ]

  const salas = [
    "Sala 101", "Sala 102", "Sala 103", "Sala 201", "Sala 202",
    "Laboratório de Ciências", "Laboratório de Informática", 
    "Biblioteca", "Auditório", "Quadra Esportiva"
  ]

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const adicionarAgendamento = () => {
    if (!formData.nomeProfessor || !formData.serie || !formData.materia || 
        !formData.horaInicial || !formData.horaFinal || !formData.quantidade || 
        !formData.data || !formData.sala) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      })
      return
    }

    const novoAgendamento = {
      id: Date.now(),
      ...formData,
      status: "pendente"
    }

    setAgendamentos(prev => [...prev, novoAgendamento])
    
    // Limpar formulário
    setFormData({
      nomeProfessor: "",
      serie: "",
      materia: "",
      horaInicial: "",
      horaFinal: "",
      quantidade: "",
      data: "",
      sala: "",
      observacoes: ""
    })

    toast({
      title: "Agendamento adicionado",
      description: "Agendamento adicionado à lista com sucesso.",
    })
  }

  const removerAgendamento = (id: number) => {
    setAgendamentos(prev => prev.filter(ag => ag.id !== id))
    toast({
      title: "Agendamento removido",
      description: "Agendamento removido da lista.",
    })
  }

  const finalizarAgendamentos = () => {
    if (agendamentos.length === 0) {
      toast({
        title: "Nenhum agendamento",
        description: "Adicione pelo menos um agendamento antes de finalizar.",
        variant: "destructive"
      })
      return
    }

    // Aqui seria enviado para o backend
    toast({
      title: "Agendamentos enviados",
      description: `${agendamentos.length} agendamento(s) enviado(s) para aprovação.`,
    })
    
    setAgendamentos([])
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Novo Agendamento</h1>
        <p className="text-muted-foreground">
          Crie novos agendamentos para suas aulas
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Formulário de Agendamento
            </CardTitle>
            <CardDescription>
              Preencha os dados para criar um novo agendamento
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="nomeProfessor">Nome do Professor *</Label>
                <Input
                  id="nomeProfessor"
                  value={formData.nomeProfessor}
                  onChange={(e) => handleInputChange("nomeProfessor", e.target.value)}
                  placeholder="Digite o nome do professor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="serie">Série *</Label>
                <Input
                  id="serie"
                  value={formData.serie}
                  onChange={(e) => handleInputChange("serie", e.target.value)}
                  placeholder="Ex: 9º Ano"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="materia">Matéria *</Label>
                <Select value={formData.materia} onValueChange={(value) => handleInputChange("materia", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma matéria" />
                  </SelectTrigger>
                  <SelectContent>
                    {materias.map((materia) => (
                      <SelectItem key={materia} value={materia}>
                        {materia}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sala">Sala *</Label>
                <Select value={formData.sala} onValueChange={(value) => handleInputChange("sala", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma sala" />
                  </SelectTrigger>
                  <SelectContent>
                    {salas.map((sala) => (
                      <SelectItem key={sala} value={sala}>
                        {sala}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="horaInicial">Hora Inicial *</Label>
                <Input
                  id="horaInicial"
                  type="time"
                  value={formData.horaInicial}
                  onChange={(e) => handleInputChange("horaInicial", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="horaFinal">Hora Final *</Label>
                <Input
                  id="horaFinal"
                  type="time"
                  value={formData.horaFinal}
                  onChange={(e) => handleInputChange("horaFinal", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantidade">Quantidade *</Label>
                <Input
                  id="quantidade"
                  type="number"
                  value={formData.quantidade}
                  onChange={(e) => handleInputChange("quantidade", e.target.value)}
                  placeholder="Nº alunos"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="data">Data *</Label>
              <Input
                id="data"
                type="date"
                value={formData.data}
                onChange={(e) => handleInputChange("data", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes}
                onChange={(e) => handleInputChange("observacoes", e.target.value)}
                placeholder="Observações adicionais sobre o agendamento..."
                rows={3}
              />
            </div>

            <Button 
              onClick={adicionarAgendamento} 
              className="w-full bg-gradient-primary hover:opacity-90"
            >
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Agendamento
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Agendamentos Adicionados ({agendamentos.length})
            </CardTitle>
            <CardDescription>
              Lista de agendamentos para envio
            </CardDescription>
          </CardHeader>
          <CardContent>
            {agendamentos.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum agendamento adicionado ainda</p>
              </div>
            ) : (
              <div className="space-y-4">
                {agendamentos.map((agendamento) => (
                  <div
                    key={agendamento.id}
                    className="p-4 border rounded-lg bg-card/50 hover:bg-card/70 transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-primary" />
                          <span className="font-medium">{agendamento.nomeProfessor}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <BookOpen className="h-3 w-3" />
                          <span>{agendamento.materia} - {agendamento.serie}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          <span>{agendamento.horaInicial} - {agendamento.horaFinal}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span>{agendamento.sala}</span>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removerAgendamento(agendamento.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                <Button 
                  onClick={finalizarAgendamentos}
                  className="w-full bg-accent hover:bg-accent/90"
                  size="lg"
                >
                  Finalizar e Enviar Agendamentos
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default NovoAgendamento