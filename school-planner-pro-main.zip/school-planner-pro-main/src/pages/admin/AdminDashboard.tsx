import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, BookOpen, MapPin, Calendar, TrendingUp, Settings, CheckCircle, Clock } from "lucide-react"

const AdminDashboard = () => {
  const stats = [
    {
      title: "Total de Professores",
      value: "45",
      description: "3 cadastrados esta semana",
      icon: Users,
      color: "text-primary",
      trend: "+12%"
    },
    {
      title: "Agendamentos Hoje",
      value: "28",
      description: "8 pendentes de aprovação",
      icon: Calendar,
      color: "text-accent",
      trend: "+5%"
    },
    {
      title: "Salas Disponíveis",
      value: "15",
      description: "12 disponíveis agora",
      icon: MapPin,
      color: "text-success",
      trend: "100%"
    },
    {
      title: "Matérias Ativas",
      value: "12",
      description: "Todas com agendamentos",
      icon: BookOpen,
      color: "text-warning",
      trend: "0%"
    }
  ]

  const recentActivities = [
    {
      id: 1,
      type: "agendamento",
      description: "Novo agendamento criado por Ana Silva",
      time: "2 min atrás",
      status: "pending"
    },
    {
      id: 2,
      type: "aprovacao",
      description: "Agendamento aprovado para João Santos",
      time: "5 min atrás",
      status: "approved"
    },
    {
      id: 3,
      type: "cadastro",
      description: "Novo professor cadastrado: Maria Costa",
      time: "1 hora atrás",
      status: "new"
    },
    {
      id: 4,
      type: "equipamento",
      description: "Projetor da Sala 201 marcado como em manutenção",
      time: "2 horas atrás",
      status: "maintenance"
    }
  ]

  const equipmentStatus = [
    { name: "Projetores", total: 15, available: 12, inUse: 2, maintenance: 1 },
    { name: "Computadores", total: 50, available: 35, inUse: 12, maintenance: 3 },
    { name: "Microscópios", total: 8, available: 6, inUse: 2, maintenance: 0 },
    { name: "Laboratórios", total: 4, available: 4, inUse: 0, maintenance: 0 }
  ]

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'agendamento':
        return <Calendar className="h-4 w-4 text-primary" />
      case 'aprovacao':
        return <CheckCircle className="h-4 w-4 text-success" />
      case 'cadastro':
        return <Users className="h-4 w-4 text-accent" />
      case 'equipamento':
        return <Settings className="h-4 w-4 text-warning" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard Administrativo</h1>
        <p className="text-muted-foreground">
          Visão geral completa do sistema de agendamento escolar
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="shadow-card hover:shadow-elegant transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{stat.description}</span>
                <span className="flex items-center gap-1 text-success">
                  <TrendingUp className="h-3 w-3" />
                  {stat.trend}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {/* Recent Activities */}
        <Card className="lg:col-span-2 shadow-card">
          <CardHeader>
            <CardTitle>Atividades Recentes</CardTitle>
            <CardDescription>
              Últimas atividades do sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-start gap-3 p-3 rounded-lg border bg-card/50 hover:bg-card/70 transition-colors"
                >
                  {getActivityIcon(activity.type)}
                  <div className="flex-1 space-y-1">
                    <p className="text-sm">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Equipment Status */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Status dos Equipamentos</CardTitle>
            <CardDescription>
              Disponibilidade em tempo real
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {equipmentStatus.map((equipment) => (
                <div key={equipment.name} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{equipment.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {equipment.available}/{equipment.total}
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-success h-2 rounded-full"
                      style={{
                        width: `${(equipment.available / equipment.total) * 100}%`
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Disponível: {equipment.available}</span>
                    <span>Em uso: {equipment.inUse}</span>
                    {equipment.maintenance > 0 && (
                      <span className="text-warning">Manutenção: {equipment.maintenance}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
          <CardDescription>
            Acesso rápido às principais funcionalidades administrativas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-gradient-card hover:shadow-card transition-shadow cursor-pointer">
              <Users className="h-8 w-8 text-primary" />
              <div>
                <h3 className="font-medium">Gerenciar Professores</h3>
                <p className="text-sm text-muted-foreground">Cadastro e edição</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-gradient-card hover:shadow-card transition-shadow cursor-pointer">
              <Calendar className="h-8 w-8 text-accent" />
              <div>
                <h3 className="font-medium">Aprovar Agendamentos</h3>
                <p className="text-sm text-muted-foreground">8 pendentes</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-gradient-card hover:shadow-card transition-shadow cursor-pointer">
              <MapPin className="h-8 w-8 text-success" />
              <div>
                <h3 className="font-medium">Configurar Salas</h3>
                <p className="text-sm text-muted-foreground">Equipamentos e layout</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-gradient-card hover:shadow-card transition-shadow cursor-pointer">
              <Settings className="h-8 w-8 text-warning" />
              <div>
                <h3 className="font-medium">Relatórios</h3>
                <p className="text-sm text-muted-foreground">Análises e estatísticas</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default AdminDashboard