import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"
import { Search, Plus, Edit, Trash2, User, Mail, Phone, Users } from "lucide-react"

interface Professor {
  id: number
  nome: string
  email: string
  telefone: string
  materias: string[]
  status: 'ativo' | 'inativo'
  dataContratacao: string
}

const AdminProfessores = () => {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProfessor, setEditingProfessor] = useState<Professor | null>(null)
  const [professores, setProfessores] = useState<Professor[]>([
    {
      id: 1,
      nome: "Ana Silva",
      email: "ana.silva@escola.com",
      telefone: "(11) 99999-1111",
      materias: ["Matemática", "Física"],
      status: "ativo",
      dataContratacao: "2023-01-15"
    },
    {
      id: 2,
      nome: "João Santos",
      email: "joao.santos@escola.com",
      telefone: "(11) 99999-2222",
      materias: ["História", "Geografia"],
      status: "ativo",
      dataContratacao: "2023-03-20"
    },
    {
      id: 3,
      nome: "Maria Costa",
      email: "maria.costa@escola.com",
      telefone: "(11) 99999-3333",
      materias: ["Português", "Literatura"],
      status: "inativo",
      dataContratacao: "2022-08-10"
    }
  ])

  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
    materias: [] as string[],
    status: "ativo" as 'ativo' | 'inativo'
  })

  const materiasDisponiveis = [
    "Matemática", "História", "Português", "Inglês", "Educação Física",
    "Educação Artística", "Maker", "Música", "Ciências", "Geografia",
    "Física", "Química", "Biologia", "Literatura"
  ]

  const filteredProfessores = professores.filter(professor =>
    professor.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    professor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    professor.materias.some(materia => 
      materia.toLowerCase().includes(searchTerm.toLowerCase())
    )
  )

  const resetForm = () => {
    setFormData({
      nome: "",
      email: "",
      telefone: "",
      materias: [],
      status: "ativo"
    })
    setEditingProfessor(null)
  }

  const openDialog = (professor?: Professor) => {
    if (professor) {
      setEditingProfessor(professor)
      setFormData({
        nome: professor.nome,
        email: professor.email,
        telefone: professor.telefone,
        materias: professor.materias,
        status: professor.status
      })
    } else {
      resetForm()
    }
    setIsDialogOpen(true)
  }

  const handleSave = () => {
    if (!formData.nome || !formData.email || formData.materias.length === 0) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      })
      return
    }

    if (editingProfessor) {
      // Editar professor existente
      setProfessores(prev => prev.map(prof => 
        prof.id === editingProfessor.id 
          ? { ...prof, ...formData }
          : prof
      ))
      toast({
        title: "Professor atualizado",
        description: "Dados do professor foram atualizados com sucesso."
      })
    } else {
      // Criar novo professor
      const novoProfessor: Professor = {
        id: Date.now(),
        ...formData,
        dataContratacao: new Date().toISOString().split('T')[0]
      }
      setProfessores(prev => [...prev, novoProfessor])
      toast({
        title: "Professor cadastrado",
        description: "Novo professor foi cadastrado com sucesso."
      })
    }

    setIsDialogOpen(false)
    resetForm()
  }

  const handleDelete = (id: number) => {
    setProfessores(prev => prev.filter(prof => prof.id !== id))
    toast({
      title: "Professor removido",
      description: "Professor foi removido do sistema."
    })
  }

  const toggleMateriaSelection = (materia: string) => {
    setFormData(prev => ({
      ...prev,
      materias: prev.materias.includes(materia)
        ? prev.materias.filter(m => m !== materia)
        : [...prev.materias, materia]
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gerenciar Professores</h1>
          <p className="text-muted-foreground">
            Cadastro e gestão dos professores da escola
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => openDialog()} className="bg-gradient-primary hover:opacity-90">
              <Plus className="h-4 w-4 mr-2" />
              Novo Professor
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingProfessor ? "Editar Professor" : "Novo Professor"}
              </DialogTitle>
              <DialogDescription>
                {editingProfessor 
                  ? "Atualize as informações do professor"
                  : "Preencha os dados do novo professor"
                }
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Completo *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                    placeholder="Digite o nome completo"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="professor@escola.com"
                  />
                </div>
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input
                    id="telefone"
                    value={formData.telefone}
                    onChange={(e) => setFormData(prev => ({ ...prev, telefone: e.target.value }))}
                    placeholder="(11) 99999-9999"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value: 'ativo' | 'inativo') => 
                      setFormData(prev => ({ ...prev, status: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Matérias * (selecione uma ou mais)</Label>
                <div className="grid grid-cols-3 gap-2 p-3 border rounded-lg max-h-40 overflow-y-auto">
                  {materiasDisponiveis.map((materia) => (
                    <div
                      key={materia}
                      onClick={() => toggleMateriaSelection(materia)}
                      className={`p-2 text-sm rounded cursor-pointer transition-colors ${
                        formData.materias.includes(materia)
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted hover:bg-muted/80"
                      }`}
                    >
                      {materia}
                    </div>
                  ))}
                </div>
                {formData.materias.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {formData.materias.map((materia) => (
                      <Badge key={materia} variant="secondary" className="text-xs">
                        {materia}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleSave} className="bg-gradient-primary hover:opacity-90">
                  {editingProfessor ? "Atualizar" : "Cadastrar"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Lista de Professores ({professores.length})
          </CardTitle>
          <CardDescription>
            Gerencie todos os professores cadastrados no sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome, email ou matéria..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Professor</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Matérias</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Contratação</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProfessores.map((professor) => (
                  <TableRow key={professor.id} className="hover:bg-muted/50">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
                          <User className="h-4 w-4 text-white" />
                        </div>
                        <span className="font-medium">{professor.nome}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="h-3 w-3 text-muted-foreground" />
                          <span>{professor.email}</span>
                        </div>
                        {professor.telefone && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            <span>{professor.telefone}</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {professor.materias.map((materia, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {materia}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={professor.status === 'ativo' ? 'default' : 'secondary'}
                        className={professor.status === 'ativo' ? 'bg-success' : 'bg-muted'}
                      >
                        {professor.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(professor.dataContratacao).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openDialog(professor)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(professor.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredProfessores.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nenhum professor encontrado</p>
              <p className="text-sm">Tente ajustar os filtros de busca</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default AdminProfessores